num1 = 36
num2 = 17
mi_bool = num1 >= num2

print("esta es la respuesta " + str(mi_bool))