def Sumar(número1, número2):
    return número1+número2

suma = Sumar(5,7)
print(suma)