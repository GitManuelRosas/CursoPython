print("El nombre de tu cerveza\nes '" + input("Que ciudad te gustaria visitar?: ") + " " + input("Cual es tu color favorito?: ") + "'\nFelicitaciones!")





